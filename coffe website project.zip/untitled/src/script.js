document.getElementById("contactForm").addEventListener("submit", function(event) {
  event.preventDefault();

  alert("Thank you! Your message has been sent.");
});
